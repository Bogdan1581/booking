package ua.edu.iot.trip_routing7

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
