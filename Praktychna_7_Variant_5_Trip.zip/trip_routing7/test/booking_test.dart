import 'package:flutter_test/flutter_test.dart';
import 'package:trip_routing7/models/hotel.dart';
import 'package:trip_routing7/state/trip_state.dart';
import 'package:trip_routing7/state/route_guard.dart';
void main() {
  test('Guard keeps city, nights and room after login', () {
    final store = TripState();
    final target = location('/hotels/1/book', 'Львів', 3, room: 'family');
    final login = tripRedirect(store, Uri.parse(target))!;
    expect(Uri.parse(login).queryParameters['from'], target);
    store.login();
    expect(tripRedirect(store, Uri.parse(login)), target);
    store.dispose();
  });
  test('Deep link preserves query and external return is rejected', () {
    final store = TripState();
    expect(tripRedirect(store, Uri.parse('trip://app/hotels/1?nights=3')), '/hotels/1?nights=3');
    expect(safeReturn('https://example.com/hotels/1'), '/hotels');
    expect(safeReturn('//example.com/hotels/1'), '/hotels');
    store.dispose();
  });
  test('Nights are restricted to 1 through 30', () {
    expect(validNights('3'), 3);
    for (final value in ['0', '-1', '31', 'abc']) { expect(validNights(value), 1); }
  });
  test('Booking validates login, room capacity and calculates total', () {
    final store = TripState();
    expect(store.book('1', 'standard', 3, 1, ''), false);
    store.login();
    expect(store.book('1', 'standard', 3, 3, ''), false);
    expect(store.book('1', 'missing', 3, 1, ''), false);
    expect(store.book('1', 'family', 3, 4, ' test '), true);
    expect(store.bookings.single.total, 7200);
    expect(store.bookings.single.comment, 'test');
    store.dispose();
  });
  test('Favorites toggle without duplicates', () {
    final store = TripState();
    store.toggleFavorite('1'); expect(store.favorite('1'), true);
    store.toggleFavorite('1'); expect(store.favorite('1'), false);
    store.dispose();
  });
}
