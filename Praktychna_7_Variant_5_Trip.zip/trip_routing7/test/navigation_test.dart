import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trip_routing7/router.dart';
import 'package:trip_routing7/state/trip_state.dart';
void main() {
  testWidgets('Hotel remains open when switching branches', (tester) async {
    final store = TripState();
    final router = createRouter(store, initialLocation: '/hotels/1?nights=3');
    await tester.pumpWidget(MaterialApp.router(routerConfig: router));
    await tester.pumpAndSettle();
    expect(find.text('Міський сад'), findsOneWidget);
    await tester.tap(find.text('Обране').last); await tester.pumpAndSettle();
    await tester.tap(find.text('Пошук').last); await tester.pumpAndSettle();
    expect(find.text('Міський сад'), findsOneWidget);
    expect(find.text('Ночей: 3'), findsOneWidget);
    await tester.pumpWidget(const SizedBox()); router.dispose(); store.dispose();
  });
  testWidgets('Guest result and dirty booking confirmation', (tester) async {
    final store = TripState()..login();
    final router = createRouter(store, initialLocation: '/hotels/1/book?nights=3');
    await tester.pumpWidget(MaterialApp.router(routerConfig: router));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Вибрати гостей')); await tester.pumpAndSettle();
    await tester.tap(find.text('2 гостей')); await tester.pumpAndSettle();
    expect(find.text('Гостей: 2'), findsOneWidget);
    await tester.tap(find.byIcon(Icons.arrow_back).last); await tester.pumpAndSettle();
    expect(find.text('Відкинути незбережені зміни?'), findsOneWidget);
    await tester.tap(find.text('Залишитися')); await tester.pumpAndSettle();
    expect(find.text('Гостей: 2'), findsOneWidget);
    await tester.pumpWidget(const SizedBox()); router.dispose(); store.dispose();
  });
}
