import 'package:flutter/foundation.dart';
import '../models/hotel.dart';
import '../models/booking.dart';
class TripState extends ChangeNotifier {
  bool signedIn = false;
  final Set<String> _favorites = {};
  final List<Booking> _bookings = [];
  List<Booking> get bookings => List.unmodifiable(_bookings);
  bool favorite(String id) => _favorites.contains(id);
  Future<bool> Function()? bookingExitGuard;
  Future<bool> mayLeaveBooking() async => await bookingExitGuard?.call() ?? true;
  void login() { signedIn = true; notifyListeners(); }
  void logout() { signedIn = false; notifyListeners(); }
  void toggleFavorite(String id) {
    if (findHotel(id) == null) return;
    if (!_favorites.add(id)) _favorites.remove(id);
    notifyListeners();
  }
  bool book(String hotelId, String roomId, int nights, int guests, String comment) {
    final hotel = findHotel(hotelId);
    if (!signedIn || hotel == null || nights < 1 || nights > 30) return false;
    final room = findRoom(hotel, roomId);
    if (room == null || guests < 1 || guests > room.capacity) return false;
    _bookings.add(Booking(hotel: hotel.name, room: room.name, nights: nights,
      guests: guests, comment: comment.trim(), total: room.price * nights, completed: false));
    notifyListeners();
    return true;
  }
}
