import 'trip_state.dart';
String safeReturn(String? raw) {
  final uri = Uri.tryParse(raw ?? '');
  if (uri == null || uri.hasScheme || uri.hasAuthority ||
      !(uri.path == '/hotels' || uri.path.startsWith('/hotels/'))) return '/hotels';
  return uri.toString();
}
String? tripRedirect(TripState store, Uri uri) {
  if (uri.scheme == 'trip' && uri.host == 'app') {
    return Uri(path: uri.path, query: uri.hasQuery ? uri.query : null).toString();
  }
  if (uri.path == '/') return '/hotels';
  final protected = RegExp(r'^/hotels/[^/]+/book(?:/guests)?$').hasMatch(uri.path);
  if (protected && !store.signedIn) {
    return Uri(path: '/login', queryParameters: {'from': uri.toString()}).toString();
  }
  if (uri.path == '/login' && store.signedIn) return safeReturn(uri.queryParameters['from']);
  return null;
}
