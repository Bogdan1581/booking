class Booking {
  const Booking({required this.hotel, required this.room, required this.nights,
    required this.guests, required this.comment, required this.total, required this.completed});
  final String hotel;
  final String room;
  final int nights;
  final int guests;
  final String comment;
  final int total;
  final bool completed;
}
