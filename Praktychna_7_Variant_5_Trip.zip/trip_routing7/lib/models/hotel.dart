class Room {
  const Room(this.id, this.name, this.price, this.capacity);
  final String id;
  final String name;
  final int price; // Гривні за ніч, лише демонстраційні дані.
  final int capacity;
}
class Hotel {
  const Hotel(this.id, this.name, this.city, this.description, this.rooms);
  final String id;
  final String name;
  final String city;
  final String description;
  final List<Room> rooms;
}
const hotels = [
  Hotel('1', 'Міський сад', 'Львів', 'Тихий готель поблизу історичного центру.', [Room('standard', 'Стандарт', 1600, 2), Room('family', 'Сімейний', 2400, 4)]),
  Hotel('2', 'Панорама', 'Київ', 'Світлі номери та зручне транспортне сполучення.', [Room('standard', 'Стандарт', 1800, 2), Room('family', 'Сімейний', 2700, 4)]),
  Hotel('3', 'Морський бриз', 'Одеса', 'Готель для спокійного відпочинку.', [Room('standard', 'Стандарт', 1500, 2), Room('family', 'Сімейний', 2200, 4)]),
  Hotel('4', 'Затишок', 'Львів', 'Невеликий готель із внутрішнім двориком.', [Room('standard', 'Стандарт', 1200, 2), Room('family', 'Сімейний', 1900, 4)]),
];
Hotel? findHotel(String id) {
  for (final h in hotels) { if (h.id == id) return h; }
  return null;
}
Room? findRoom(Hotel h, String id) {
  for (final r in h.rooms) { if (r.id == id) return r; }
  return null;
}
int validNights(String? input) {
  final n = int.tryParse(input ?? '');
  return n != null && n >= 1 && n <= 30 ? n : 1;
}
String location(String path, String city, int nights, {String? room}) =>
  Uri(path: path, queryParameters: {'city': city, 'nights': '$nights', if (room != null) 'room': room}).toString();
