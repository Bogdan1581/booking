import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'models/hotel.dart';
import 'state/trip_state.dart';
import 'state/route_guard.dart';
import 'screens/search_screen.dart';
import 'screens/hotel_screen.dart';
import 'screens/room_screen.dart';
import 'screens/booking_screen.dart';
import 'screens/guests_screen.dart';
import 'screens/other_screens.dart';
GoRouter createRouter(TripState store, {String? initialLocation}) {
  final root = GlobalKey<NavigatorState>();
  return GoRouter(navigatorKey: root, initialLocation: initialLocation ?? '/hotels',
    refreshListenable: store, redirect: (_, s) => tripRedirect(store, s.uri),
    errorBuilder: (_, s) => ErrorScreen(message: 'Невідома адреса: ${s.uri.path}'),
    routes: [
      GoRoute(path: '/login', builder: (_, _) => LoginScreen(store: store)),
      StatefulShellRoute.indexedStack(builder: (_, _, shell) => Scaffold(body: shell,
        bottomNavigationBar: NavigationBar(selectedIndex: shell.currentIndex,
          onDestinationSelected: (i) => shell.goBranch(i), destinations: const [
            NavigationDestination(icon: Icon(Icons.search), label: 'Пошук'),
            NavigationDestination(icon: Icon(Icons.luggage), label: 'Поїздки'),
            NavigationDestination(icon: Icon(Icons.favorite), label: 'Обране'),
          ])), branches: [
        StatefulShellBranch(routes: [GoRoute(path: '/hotels', builder: (_, s) => SearchScreen(
          city: s.uri.queryParameters['city'] ?? '', nights: validNights(s.uri.queryParameters['nights'])), routes: [
          GoRoute(path: ':hotelId', builder: (_, s) => HotelScreen(store: store,
            id: s.pathParameters['hotelId']!, city: s.uri.queryParameters['city'] ?? '', nights: validNights(s.uri.queryParameters['nights'])), routes: [
            GoRoute(path: 'rooms/:roomId', builder: (_, s) => RoomScreen(
              hotelId: s.pathParameters['hotelId']!, roomId: s.pathParameters['roomId']!,
              city: s.uri.queryParameters['city'] ?? '', nights: validNights(s.uri.queryParameters['nights']))),
            GoRoute(path: 'book', parentNavigatorKey: root, onExit: (_, _) => store.mayLeaveBooking(),
              builder: (_, s) => BookingScreen(store: store, hotelId: s.pathParameters['hotelId']!,
                roomId: s.uri.queryParameters['room'] ?? 'standard', city: s.uri.queryParameters['city'] ?? '',
                nights: validNights(s.uri.queryParameters['nights'])), routes: [
                GoRoute(path: 'guests', parentNavigatorKey: root, builder: (_, s) {
                  final hotel = findHotel(s.pathParameters['hotelId']!);
                  final room = hotel == null ? null : findRoom(hotel, s.uri.queryParameters['room'] ?? 'standard');
                  if (room == null) return const ErrorScreen(message: 'Номер не знайдено');
                  return GuestsScreen(capacity: room.capacity);
                }),
              ]),
          ]),
        ])]),
        StatefulShellBranch(routes: [GoRoute(path: '/trips', builder: (_, _) => TripsScreen(store: store))]),
        StatefulShellBranch(routes: [GoRoute(path: '/favorites', builder: (_, _) => FavoritesScreen(store: store))]),
      ]),
    ]);
}
