import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'router.dart';
import 'state/trip_state.dart';
void main() => runApp(const TripApp());
class TripApp extends StatefulWidget {
  const TripApp({super.key});
  @override
  State<TripApp> createState() => _TripAppState();
}
class _TripAppState extends State<TripApp> {
  final store = TripState();
  late final GoRouter router = createRouter(store);
  @override
  void dispose() { router.dispose(); store.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => MaterialApp.router(
    debugShowCheckedModeBanner: false, title: 'Подорожі', routerConfig: router,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF176B62)), useMaterial3: true));
}
