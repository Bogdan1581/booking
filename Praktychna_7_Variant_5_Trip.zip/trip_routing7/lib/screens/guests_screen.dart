import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
class GuestsScreen extends StatelessWidget {
  const GuestsScreen({super.key, required this.capacity});
  final int capacity;
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Кількість гостей')),
    body: ListView(children: [for (var n = 1; n <= capacity; n++)
      ListTile(title: Text('$n гостей'), onTap: () => context.pop<int>(n))]));
}
