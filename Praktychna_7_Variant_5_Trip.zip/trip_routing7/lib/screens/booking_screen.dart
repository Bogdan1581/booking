import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../models/hotel.dart';
import '../state/trip_state.dart';
import 'other_screens.dart';
class BookingScreen extends StatefulWidget {
  const BookingScreen({super.key, required this.store, required this.hotelId, required this.roomId,
    required this.city, required this.nights});
  final TripState store;
  final String hotelId;
  final String roomId;
  final String city;
  final int nights;
  @override
  State<BookingScreen> createState() => _BookingScreenState();
}
class _BookingScreenState extends State<BookingScreen> {
  final _comment = TextEditingController();
  int _guests = 1;
  bool _dirty = false;
  bool _allowPop = false;
  bool _asking = false;
  bool _choosing = false;
  bool _closing = false;
  @override
  void initState() { super.initState(); widget.store.bookingExitGuard = _confirmLeave; }
  @override
  void dispose() { widget.store.bookingExitGuard = null; _comment.dispose(); super.dispose(); }
  Future<bool> _confirmLeave() async {
    if (_allowPop || !_dirty) return true;
    if (_asking) return false;
    _asking = true;
    final leave = await showDialog<bool>(context: context, builder: (dialogContext) => AlertDialog(
      title: const Text('Відкинути незбережені зміни?'),
      actions: [
        TextButton(onPressed: () => Navigator.of(dialogContext).pop(false), child: const Text('Залишитися')),
        FilledButton(onPressed: () => Navigator.of(dialogContext).pop(true), child: const Text('Відкинути')),
      ]));
    if (!mounted) return false;
    _asking = false;
    if (leave != true) return false;
    setState(() => _allowPop = true);
    return true;
  }
  Future<void> _back() async {
    if (_closing) return;
    final leave = await _confirmLeave();
    if (!mounted || !leave) return;
    _closing = true;
    await WidgetsBinding.instance.endOfFrame;
    if (!mounted) return;
    context.pop();
  }
  Future<void> _chooseGuests() async {
    if (_choosing) return;
    setState(() => _choosing = true);
    final count = await context.push<int>(location('/hotels/${widget.hotelId}/book/guests',
      widget.city, widget.nights, room: widget.roomId));
    if (!mounted) return;
    setState(() {
      _choosing = false;
      if (count != null && count != _guests) { _guests = count; _dirty = true; }
    });
  }
  Future<void> _save() async {
    if (_closing) return;
    // Дозвіл виходу встановлюємо до notifyListeners у моделі.
    _allowPop = true;
    if (!widget.store.book(widget.hotelId, widget.roomId, widget.nights, _guests, _comment.text)) {
      _allowPop = false;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Перевірте номер, кількість гостей та вхід.')));
      return;
    }
    _closing = true;
    setState(() => _dirty = false);
    await WidgetsBinding.instance.endOfFrame;
    if (!mounted) return;
    context.go('/trips');
  }
  @override
  Widget build(BuildContext context) {
    final hotel = findHotel(widget.hotelId);
    final room = hotel == null ? null : findRoom(hotel, widget.roomId);
    if (hotel == null || room == null) return const ErrorScreen(message: 'Готель або номер не знайдено');
    return PopScope<Object?>(canPop: _allowPop || !_dirty,
      onPopInvokedWithResult: (didPop, result) { if (!didPop) _back(); },
      child: Scaffold(appBar: AppBar(title: const Text('Бронювання'),
        leading: IconButton(onPressed: _back, icon: const Icon(Icons.arrow_back))),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          Text('${hotel.name} • ${room.name}'), Text('Місто пошуку: ${widget.city.isEmpty ? "усі" : widget.city}'),
          Text('Ночей: ${widget.nights}'), Text('Гостей: $_guests', key: const ValueKey('guest-count')),
          OutlinedButton(onPressed: _choosing ? null : _chooseGuests, child: const Text('Вибрати гостей')),
          TextField(controller: _comment, maxLines: 3, decoration: const InputDecoration(labelText: 'Коментар'),
            onChanged: (_) => setState(() => _dirty = true)),
          Text('Разом: ${room.price * widget.nights} грн'),
          const Text('Навчальна імітація: оплата та реальне бронювання не здійснюються.'),
          FilledButton(onPressed: _closing ? null : _save, child: const Text('Підтвердити бронювання')),
        ])));
  }
}
