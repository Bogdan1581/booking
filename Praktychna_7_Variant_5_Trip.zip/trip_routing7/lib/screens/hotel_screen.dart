import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../models/hotel.dart';
import '../state/trip_state.dart';
import 'other_screens.dart';
class HotelScreen extends StatelessWidget {
  const HotelScreen({super.key, required this.store, required this.id, required this.city, required this.nights});
  final TripState store;
  final String id;
  final String city;
  final int nights;
  @override
  Widget build(BuildContext context) {
    final hotel = findHotel(id);
    if (hotel == null) return const ErrorScreen(message: 'Готель не знайдено');
    return Scaffold(appBar: AppBar(title: Text(hotel.name)), body: ListView(padding: const EdgeInsets.all(20), children: [
      Text(hotel.city, style: Theme.of(context).textTheme.titleLarge), Text(hotel.description),
      Text('Ночей: $nights', key: const ValueKey('hotel-nights')),
      ListenableBuilder(listenable: store, builder: (_, _) => OutlinedButton.icon(
        onPressed: () => store.toggleFavorite(id), icon: Icon(store.favorite(id) ? Icons.favorite : Icons.favorite_border),
        label: Text(store.favorite(id) ? 'Видалити з обраного' : 'В обране'))),
      for (final room in hotel.rooms) Card(child: ListTile(title: Text(room.name),
        subtitle: Text('${room.price} грн/ніч • до ${room.capacity} гостей'),
        onTap: () => context.go(location('/hotels/$id/rooms/${room.id}', city, nights)))),
      FilledButton(onPressed: () => context.go(location('/hotels/$id/book', city, nights)), child: const Text('Бронювати стандарт')),
    ]));
  }
}
