import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../models/hotel.dart';
import 'other_screens.dart';
class RoomScreen extends StatelessWidget {
  const RoomScreen({super.key, required this.hotelId, required this.roomId, required this.city, required this.nights});
  final String hotelId;
  final String roomId;
  final String city;
  final int nights;
  @override
  Widget build(BuildContext context) {
    final hotel = findHotel(hotelId);
    final room = hotel == null ? null : findRoom(hotel, roomId);
    if (room == null) return const ErrorScreen(message: 'Номер не знайдено');
    return Scaffold(appBar: AppBar(title: Text(room.name)), body: ListView(padding: const EdgeInsets.all(20), children: [
      Text('До ${room.capacity} гостей'), Text('$nights ночей: ${nights * room.price} грн'),
      FilledButton(onPressed: () => context.go(location('/hotels/$hotelId/book', city, nights, room: roomId)), child: const Text('Бронювати')),
    ]));
  }
}
