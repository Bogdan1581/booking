import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../models/hotel.dart';
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key, required this.city, required this.nights});
  final String city;
  final int nights;
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}
class _SearchScreenState extends State<SearchScreen> {
  late final TextEditingController _city = TextEditingController(text: widget.city);
  late int _nights = widget.nights;
  @override
  void didUpdateWidget(covariant SearchScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.city != widget.city) _city.text = widget.city;
    if (oldWidget.nights != widget.nights) _nights = widget.nights;
  }
  @override
  void dispose() { _city.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    final found = hotels.where((h) => h.city.toLowerCase().contains(widget.city.trim().toLowerCase())).toList();
    return Scaffold(appBar: AppBar(title: const Text('Пошук житла')), body: ListView(
      key: const PageStorageKey('hotels-list'), padding: const EdgeInsets.all(20), children: [
        TextField(controller: _city, decoration: const InputDecoration(labelText: 'Місто (Львів, Київ, Одеса)')),
        DropdownButton<int>(value: _nights, items: [for (var n = 1; n <= 30; n++)
          DropdownMenuItem(value: n, child: Text('$n ночей'))], onChanged: (n) => setState(() => _nights = n!)),
        FilledButton(onPressed: () => context.go(location('/hotels', _city.text.trim(), _nights)), child: const Text('Знайти')),
        const SizedBox(height: 16),
        if (found.isEmpty) const Text('Нічого не знайдено. Спробуйте інше місто.'),
        for (final h in found) Card(child: ListTile(leading: const Icon(Icons.hotel), title: Text(h.name),
          subtitle: Text('${h.city} • від ${h.rooms.first.price} грн/ніч'),
          onTap: () => context.go(location('/hotels/${h.id}', widget.city, widget.nights)))),
      ]));
  }
}
