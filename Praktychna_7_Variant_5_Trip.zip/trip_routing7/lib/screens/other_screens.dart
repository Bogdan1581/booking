import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../models/hotel.dart';
import '../state/trip_state.dart';
class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key, required this.store});
  final TripState store;
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Вхід')),
    body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Text('Демонстраційний вхід без пароля'),
      FilledButton(onPressed: store.login, child: const Text('Увійти')),
      TextButton(onPressed: () => context.go('/hotels'), child: const Text('Скасувати')),
    ])));
}
class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key, required this.store});
  final TripState store;
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Обране')),
    body: ListenableBuilder(listenable: store, builder: (_, _) {
      final saved = hotels.where((h) => store.favorite(h.id)).toList();
      if (saved.isEmpty) return const Center(child: Text('Додайте готель до обраного'));
      return ListView(children: [for (final h in saved) ListTile(title: Text(h.name), subtitle: Text(h.city),
        trailing: IconButton(onPressed: () => store.toggleFavorite(h.id), icon: const Icon(Icons.delete_outline)),
        onTap: () => context.go(location('/hotels/${h.id}', h.city, 1)))]);
    }));
}
class TripsScreen extends StatelessWidget {
  const TripsScreen({super.key, required this.store});
  final TripState store;
  @override
  Widget build(BuildContext context) => DefaultTabController(length: 2, child: Scaffold(
    appBar: AppBar(title: const Text('Мої поїздки'), actions: [
      ListenableBuilder(listenable: store, builder: (_, _) => TextButton(
        onPressed: store.signedIn ? store.logout : () => context.go('/login'),
        child: Text(store.signedIn ? 'Вийти' : 'Вхід'))),
    ], bottom: const TabBar(tabs: [Tab(text: 'Майбутні'), Tab(text: 'Минулі')])),
    body: ListenableBuilder(listenable: store, builder: (_, _) => TabBarView(children: [
      for (final completed in [false, true]) Builder(builder: (_) {
        final items = store.bookings.where((b) => b.completed == completed).toList();
        if (items.isEmpty) return Center(child: Text(completed ? 'Минулих поїздок немає' : 'Бронювань поки немає'));
        return ListView.builder(itemCount: items.length, itemBuilder: (_, i) {
          final b = items[i];
          return Card(child: ListTile(title: Text(b.hotel), subtitle: Text(
            '${b.room} • ${b.nights} ночей • ${b.guests} гостей\n${b.total} грн\n${b.comment}')));
        });
      }),
    ]))));
}
class ErrorScreen extends StatelessWidget {
  const ErrorScreen({super.key, required this.message});
  final String message;
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Помилка')),
    body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Text(message),
      FilledButton(onPressed: () => context.go('/hotels'), child: const Text('До пошуку'))])));
}
